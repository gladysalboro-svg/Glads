/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.login;

/**
 *
 * @author CL1-13
 */
public class Login {

    public static void main(String[] args) {
       login1 frame= new login1();
                frame.setVisible(true);
                frame.pack();
                frame.setLocationRelativeTo(null);
                
        
    }
}
